<?php
/**
 * Tutoriales Lucio · CODLYX — catálogo de respaldo y whitelist de vistas
 * ---------------------------------------------------------------------
 * Este fichero cumple DOS funciones, ambas de seguridad o continuidad:
 *
 *  1. `views`   — WHITELIST. El campo `view_key` llega desde MySQL, es
 *                 decir, desde fuera del código. Jamás se concatena a una
 *                 ruta de fichero. Solo se acepta si es una clave EXACTA
 *                 de este array; el valor es el nombre de vista real.
 *                 Sin esto, un `view_key` como '../../config/config'
 *                 sería path traversal. Con esto, es simplemente inválido.
 *
 *  2. `tutorials` — CATÁLOGO DE RESPALDO. Si MySQL está deshabilitado,
 *                 mal configurado o caído, la biblioteca se sirve desde
 *                 aquí y el sitio sigue siendo navegable. Mantén esta
 *                 lista alineada con database/seed.sql.
 *
 * Al añadir un tutorial nuevo hay que tocar los DOS arrays. El README
 * lo explica paso a paso en «Agregar un nuevo tutorial».
 */

declare(strict_types=1);

return [

    /**
     * Whitelist  view_key => nombre de vista en app/Views/tutorials/<nombre>.php
     * La clave debe coincidir con tutorials.view_key en la base de datos.
     */
    'views' => [
        'wireshark' => 'wireshark',
    ],

    /**
     * Catálogo de respaldo. Mismos campos que devuelve la consulta SQL,
     * para que las vistas no distingan de dónde vienen los datos.
     */
    'tutorials' => [
        [
            'slug'        => 'wireshark',
            'name'        => 'Wireshark',
            'tagline'     => 'Análisis de paquetes y ciberseguridad defensiva',
            'description' => 'Curso completo en cinco partes: fundamentos de captura, los protocolos capa por capa (Ethernet, ARP, IPv4, IPv6, ICMP, TCP, UDP, DNS, DHCP, HTTP y TLS), las herramientas de Wireshark a fondo, análisis defensivo de tráfico y doce laboratorios prácticos con desafíos.',
            'icon'        => 'wireshark',
            'view_key'    => 'wireshark',
            'status'      => 'available',
            'category'    => 'Redes',
            'sort_order'  => 10,
        ],
        [
            'slug'        => 'ssh',
            'name'        => 'SSH',
            'tagline'     => 'Acceso remoto seguro',
            'description' => '',
            'icon'        => 'ssh',
            'view_key'    => null,
            'status'      => 'coming_soon',
            'category'    => 'Sistemas',
            'sort_order'  => 20,
        ],
    ],

    /**
     * Índice de secciones de respaldo, por slug de tutorial.
     * Espejo de la tabla tutorial_sections.
     */
    'sections' => [
        'wireshark' => [
            ['anchor' => 'que-es',           'label' => 'Qué es Wireshark',        'badge' => '01', 'group' => 'Fundamentos'],
            ['anchor' => 'instalar',         'label' => 'Instalar y permisos',     'badge' => '02', 'group' => 'Fundamentos'],
            ['anchor' => 'interfaz',         'label' => 'La interfaz por dentro',  'badge' => '03', 'group' => 'Fundamentos'],
            ['anchor' => 'ventana',          'label' => 'Los tres paneles',        'badge' => '04', 'group' => 'Fundamentos'],
            ['anchor' => 'mental',           'label' => 'Encapsulación y capas',   'badge' => '05', 'group' => 'Fundamentos'],
            ['anchor' => 'filtros',          'label' => 'Captura vs. visualización', 'badge' => '06', 'group' => 'Fundamentos'],
            ['anchor' => 'display-filters',  'label' => 'Lenguaje de filtros',     'badge' => '07', 'group' => 'Fundamentos'],
            ['anchor' => 'ethernet',         'label' => 'Ethernet',                'badge' => '08', 'group' => 'Protocolos'],
            ['anchor' => 'arp',              'label' => 'ARP',                     'badge' => '09', 'group' => 'Protocolos'],
            ['anchor' => 'ipv4',             'label' => 'IPv4',                    'badge' => '10', 'group' => 'Protocolos'],
            ['anchor' => 'ipv6',             'label' => 'IPv6',                    'badge' => '11', 'group' => 'Protocolos'],
            ['anchor' => 'icmp',             'label' => 'ICMP',                    'badge' => '12', 'group' => 'Protocolos'],
            ['anchor' => 'tcp',              'label' => 'TCP',                     'badge' => '13', 'group' => 'Protocolos'],
            ['anchor' => 'udp',              'label' => 'UDP',                     'badge' => '14', 'group' => 'Protocolos'],
            ['anchor' => 'dns',              'label' => 'DNS',                     'badge' => '15', 'group' => 'Protocolos'],
            ['anchor' => 'dhcp',             'label' => 'DHCP',                    'badge' => '16', 'group' => 'Protocolos'],
            ['anchor' => 'http',             'label' => 'HTTP',                    'badge' => '17', 'group' => 'Protocolos'],
            ['anchor' => 'tls',              'label' => 'HTTPS y TLS',             'badge' => '18', 'group' => 'Protocolos'],
            ['anchor' => 'follow',           'label' => 'Follow Stream',           'badge' => '19', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'statistics',       'label' => 'Statistics',              'badge' => '20', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'expert',           'label' => 'Expert Information',      'badge' => '21', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'coloring',         'label' => 'Coloring rules',          'badge' => '22', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'columnas',         'label' => 'Columnas propias',        'badge' => '23', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'perfiles',         'label' => 'Perfiles',                'badge' => '24', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'tls-descifrado',   'label' => 'Descifrar TLS propio',    'badge' => '25', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'tshark',           'label' => 'tshark',                  'badge' => '26', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'pcap',             'label' => 'PCAP y su custodia',      'badge' => '27', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'ciber',            'label' => 'Análisis defensivo',      'badge' => '28', 'group' => 'Ciberseguridad'],
            ['anchor' => 'baseline',         'label' => 'Línea base',              'badge' => '29', 'group' => 'Ciberseguridad'],
            ['anchor' => 'scan',             'label' => 'Escaneo de puertos',      'badge' => '30', 'group' => 'Ciberseguridad'],
            ['anchor' => 'beaconing',        'label' => 'Beaconing',               'badge' => '31', 'group' => 'Ciberseguridad'],
            ['anchor' => 'dns-raro',         'label' => 'DNS sospechoso',          'badge' => '32', 'group' => 'Ciberseguridad'],
            ['anchor' => 'arp-raro',         'label' => 'ARP anómalo',             'badge' => '33', 'group' => 'Ciberseguridad'],
            ['anchor' => 'exfil',            'label' => 'Exfiltración',            'badge' => '34', 'group' => 'Ciberseguridad'],
            ['anchor' => 'http-raro',        'label' => 'HTTP sospechoso',         'badge' => '35', 'group' => 'Ciberseguridad'],
            ['anchor' => 'claro',            'label' => 'Credenciales en claro',   'badge' => '36', 'group' => 'Ciberseguridad'],
            ['anchor' => 'resets',           'label' => 'Resets y pérdidas',       'badge' => '37', 'group' => 'Ciberseguridad'],
            ['anchor' => 'flujo',            'label' => 'Flujo de análisis',       'badge' => '38', 'group' => 'Ciberseguridad'],
            ['anchor' => 'informe',          'label' => 'Informe de incidente',    'badge' => '39', 'group' => 'Ciberseguridad'],
            ['anchor' => 'labs',             'label' => '12 laboratorios',         'badge' => '40', 'group' => 'Práctica'],
            ['anchor' => 'desafios',         'label' => 'Desafíos',                'badge' => '41', 'group' => 'Práctica'],
            ['anchor' => 'errores',          'label' => 'Errores comunes',         'badge' => '42', 'group' => 'Práctica'],
            ['anchor' => 'chuleta',          'label' => 'Chuleta de filtros',      'badge' => '43', 'group' => 'Práctica'],
        ],
    ],
];
