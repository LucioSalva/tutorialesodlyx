<?php
/**
 * Tutorial: Wireshark en 9 capturas
 * ---------------------------------------------------------------------
 * Contenido migrado íntegramente desde /home/lucio/wireshark-lab.html.
 * El texto educativo se conserva palabra por palabra; lo que cambia es el
 * marcado (semántico, componentizado) y la presentación.
 *
 * Los identificadores de sección (instalar, mental, ventana, filtros,
 * e1..e9, chuleta) son los MISMOS del laboratorio original, de modo que
 * cualquier enlace antiguo con ancla sigue funcionando.
 *
 * Los bloques repetidos se generan con term(), filter_chip() y note()
 * de components/blocks.php.
 */
require_once \App\Core\Config::basePath('app/Views/components/icons.php');
require_once \App\Core\Config::basePath('app/Views/components/blocks.php');
?>

<!-- Entradilla original del laboratorio, conservada palabra por palabra:
     es la que fija la promesa del tutorial y el orden de lectura. -->
<p class="tl-eyebrow">Guía práctica · CachyOS · wlan0 — «Wireshark en 9 capturas»</p>
<p class="tut-lead">
  Nueve ejercicios en orden, cada uno construido sobre el anterior. Abres Wireshark,
  ejecutas el comando, miras lo que aparece. Al final sabes leer una conversación de red
  entera.
</p>

<!-- ============================ INSTALAR ============================ -->
<section id="instalar">
  <h2>Antes de empezar: instalar</h2>
  <p class="tut-sub">Dos paquetes y un grupo de usuario.</p>

  <p>Wireshark en Arch viene partido en dos: <code>wireshark-cli</code> trae el motor de
  captura y las herramientas de terminal, <code>wireshark-qt</code> añade la interfaz
  gráfica. Instalando el segundo entra el primero como dependencia.</p>

  <?= term('<span class="p">$</span> sudo pacman -S wireshark-qt') ?>

  <p>Capturar paquetes es una operación privilegiada: le estás pidiendo al kernel que te
  entregue tramas en crudo de la tarjeta de red. Ejecutar toda la GUI como root sería una
  mala idea (es un programa enorme que parsea datos hostiles de la red), así que Wireshark
  aísla esa parte en un binario diminuto, <code>dumpcap</code>, y da acceso solo a los
  miembros del grupo <code>wireshark</code>.</p>

  <?= term('<span class="p">$</span> sudo usermod -aG wireshark $USER') ?>

  <?= note('Importante',
      '<p>El grupo no se aplica hasta que vuelves a iniciar sesión. Cierra sesión y entra
      de nuevo, o reinicia. Comprueba con <code>id | grep wireshark</code> — si no aparece,
      todavía no ha entrado en vigor y Wireshark te mostrará la lista de interfaces vacía.</p>') ?>

  <p>Verifica que todo está en su sitio:</p>

  <?= term('<span class="p">$</span> tshark --version | head -1' . "\n"
         . '<span class="p">$</span> getcap /usr/bin/dumpcap' . "\n"
         . '<span class="c">/usr/bin/dumpcap cap_net_admin,cap_net_raw=ep</span>') ?>

  <p>Esas dos <em>capabilities</em> son exactamente los permisos mínimos:
  <code>cap_net_raw</code> para leer tramas crudas y <code>cap_net_admin</code> para poner
  la interfaz en modo promiscuo. Nada más.</p>
</section>

<!-- ========================== MODELO MENTAL ========================= -->
<section id="mental">
  <h2>El modelo mental</h2>
  <p class="tut-sub">Un paquete es una cebolla. Wireshark la pela.</p>

  <p>Cuando tu navegador pide una página, ese dato no viaja solo: cada capa de la pila de
  red lo envuelve con su propia cabecera antes de pasarlo abajo. Lo que sale por la antena
  wifi es este bloque de bytes:</p>

  <figure class="encap">
    <div class="encap__row">
      <div class="l2"><span class="encap__k">Ethernet</span><span class="encap__b">14 bytes</span></div>
      <div class="l3"><span class="encap__k">IPv4</span><span class="encap__b">20 bytes</span></div>
      <div class="l4"><span class="encap__k">TCP</span><span class="encap__b">20+ bytes</span></div>
      <div class="l7"><span class="encap__k">HTTP · datos</span><span class="encap__b">lo que realmente querías</span></div>
    </div>
    <figcaption class="visually-hidden">
      Diagrama de encapsulado: la cabecera Ethernet de 14 bytes envuelve la cabecera IPv4
      de 20 bytes, que envuelve la cabecera TCP de 20 o más bytes, que envuelve los datos
      HTTP.
    </figcaption>
    <ul class="encap__legend">
      <li><i class="l2" aria-hidden="true"></i>MAC origen y destino — el salto físico</li>
      <li><i class="l3" aria-hidden="true"></i>IP origen y destino — la ruta global</li>
      <li><i class="l4" aria-hidden="true"></i>Puertos, secuencia, flags — la conversación</li>
      <li><i class="l7" aria-hidden="true"></i>El contenido</li>
    </ul>
  </figure>

  <p>Cada capa solo sabe de la siguiente. Ethernet entrega la trama al router de al lado;
  IP sabe llevarla hasta el otro extremo del mundo; TCP se encarga de que llegue completa
  y en orden; HTTP es el idioma que hablan los dos programas. Wireshark hace una cosa:
  coge esos bytes y te los desmonta capa por capa, con nombres.</p>

  <p>Y algo que conviene tener claro desde el principio: <strong>Wireshark no toca
  nada</strong>. No bloquea, no modifica, no inyecta. Es un microscopio, no un cortafuegos.
  Si algo va mal en tu red, Wireshark te dice qué está pasando, pero arreglarlo es otra
  herramienta.</p>
</section>

<!-- ============================ LA VENTANA ========================== -->
<section id="ventana">
  <h2>La ventana: tres paneles</h2>
  <p class="tut-sub">Siempre son los mismos tres, siempre significan lo mismo.</p>

  <dl class="panes">
    <div>
      <dt>Arriba · Packet List</dt>
      <dd>Una línea por paquete. <b>No.</b> orden de captura · <b>Time</b> segundos desde
      que empezaste · <b>Source</b> y <b>Destination</b> · <b>Protocol</b> el más alto que
      Wireshark supo reconocer · <b>Length</b> bytes totales · <b>Info</b> el resumen
      legible. Los colores vienen de reglas configurables: negro sobre rojo casi siempre
      significa problema.</dd>
    </div>
    <div>
      <dt>Medio · Packet Details</dt>
      <dd>El paquete seleccionado, desmontado en el árbol de capas de arriba. Cada rama se
      despliega. <b>Aquí es donde se aprende</b>: despliega TCP y verás los puertos, el
      número de secuencia, los flags, la ventana. Clic derecho sobre cualquier campo →
      <b>Apply as Filter</b> construye el filtro por ti.</dd>
    </div>
    <div>
      <dt>Abajo · Packet Bytes</dt>
      <dd>Los bytes reales en hexadecimal y ASCII. Al pinchar un campo del árbol, se
      resaltan sus bytes aquí. Es la prueba de que el árbol no se inventa nada: cada nombre
      bonito corresponde a una posición concreta.</dd>
    </div>
  </dl>

  <p>Para empezar una captura: doble clic en <code>wlan0</code> en la pantalla de inicio.
  La sparkline al lado de cada interfaz muestra actividad — así sabes cuál está viva antes
  de elegir. Para parar, el cuadrado rojo. Para descartar y volver a empezar, la escoba.</p>
</section>

<!-- ============================= FILTROS ============================ -->
<section id="filtros">
  <h2>Filtros: la distinción que hay que interiorizar</h2>
  <p class="tut-sub">Hay dos tipos de filtro y no se parecen en nada.</p>

  <p>Este es el punto donde más gente se atasca. Wireshark tiene <strong>dos sistemas de
  filtrado distintos, con sintaxis distintas, en momentos distintos</strong>.</p>

  <h4>Capture filter — antes de capturar</h4>
  <p>Se escribe en la pantalla de inicio, debajo de la lista de interfaces. Decide qué
  paquetes se guardan y cuáles se tiran a la basura sin mirarlos. Usa sintaxis BPF, la
  misma de <code>tcpdump</code>: <code>host 1.1.1.1</code>, <code>port 53</code>,
  <code>tcp and not port 22</code>. Lo que descartas aquí, lo pierdes para siempre. Se usa
  cuando el volumen es tan alto que capturarlo todo no es viable.</p>

  <h4>Display filter — después de capturar</h4>
  <p>La barra verde ancha en la parte superior de la ventana principal. Filtra la
  <em>vista</em>; los paquetes ocultos siguen ahí y vuelven en cuanto borras el filtro.
  Sintaxis propia de Wireshark, mucho más rica: <code>ip.addr == 1.1.1.1</code>,
  <code>dns</code>, <code>tcp.flags.syn == 1 &amp;&amp; tcp.flags.ack == 0</code>.</p>

  <?= note('Regla práctica',
      '<p>Salvo que estés capturando en un enlace saturado, <strong>captura todo y filtra
      en la vista</strong>. El display filter es el que vas a usar el 95 % del tiempo, y es
      el que enseñan los nueve ejercicios de abajo. La barra se pone verde si la sintaxis
      es válida y roja si no.</p>', 'info') ?>

  <p>Dos detalles de sintaxis que ahorran confusión: <code>ip.addr == X</code> significa
  «origen <em>o</em> destino es X», mientras que <code>ip.src</code> e <code>ip.dst</code>
  son direccionales. Y escribir solo el nombre de un protocolo (<code>dns</code>,
  <code>tls</code>, <code>arp</code>) filtra todos los paquetes que lo contienen — es el
  filtro más útil y más corto que existe.</p>
</section>

<!-- ====================== EJERCICIO 01 · ICMP ======================= -->
<section id="e1">
  <h2>Los nueve ejercicios</h2>
  <p class="tut-sub">Wireshark en una ventana, terminal en la otra. En orden.</p>

  <div class="lab">
    <div class="lab__head"><span class="lab__num">01</span><h3>Ping: tu primer paquete</h3></div>
    <p class="lab__goal">Objetivo: leer el árbol de capas de un paquete que entiendes entero.</p>

    <p>Empieza la captura en <code>wlan0</code>. Verás una avalancha de tráfico de fondo —
    es normal, tu equipo habla solo todo el rato. Pega este filtro en la barra verde para
    quedarte solo con lo tuyo:</p>

    <?= filter_chip('icmp') ?>

    <p>La lista se queda vacía. Ahora, en la terminal:</p>

    <?= term('<span class="p">$</span> ping -c 4 1.1.1.1') ?>

    <p>Aparecen ocho paquetes: cuatro <em>Echo (ping) request</em> y cuatro <em>Echo (ping)
    reply</em>, alternados. Selecciona el primer request y despliega el árbol del panel del
    medio. Vas a ver exactamente las tres capas del diagrama de arriba:</p>

    <ul>
      <li><strong>Ethernet II</strong> — origen <code>b8:1e:a4:5a:ac:8d</code> (tu tarjeta
      wifi) y destino la MAC de tu router. Fíjate: la MAC destino <em>no</em> es la de
      Cloudflare. Es la del siguiente salto.</li>
      <li><strong>Internet Protocol Version 4</strong> — origen <code>10.2.3.170</code>,
      destino <code>1.1.1.1</code>. Aquí sí está el destino final. Despliega y busca
      <code>Time to Live</code>: es el contador de saltos que evita que un paquete perdido
      dé vueltas para siempre.</li>
      <li><strong>Internet Control Message Protocol</strong> — tipo 8 (request). En la
      respuesta será tipo 0 (reply). Al final hay un campo <code>Data</code> con bytes de
      relleno.</li>
    </ul>

    <p>Pincha el campo TTL en el árbol y mira el panel de abajo: se resalta un byte. Ese
    byte <em>es</em> el TTL. No hay magia.</p>

    <?= note('Por qué importa',
        '<p>ICMP es el protocolo más simple que hay, y por eso es el mejor sitio para
        aprender a leer el árbol. Todo lo demás usa la misma estructura, solo que con más
        capas encima.</p>', 'info') ?>
  </div>
</section>

<!-- ======================= EJERCICIO 02 · ARP ======================= -->
<section class="lab" id="e2">
  <div class="lab__head"><span class="lab__num">02</span><h3>ARP: cómo encuentra tu equipo al router</h3></div>
  <p class="lab__goal">Objetivo: ver la capa 2 en acción, por debajo de IP.</p>

  <p>En el ejercicio anterior tu equipo puso la MAC del router en la trama. ¿Cómo la sabía?
  La preguntó a gritos. Filtra:</p>

  <?= filter_chip('arp') ?>

  <p>Fuerza uno borrando la entrada de la tabla y volviendo a hablar con el router:</p>

  <?= term('<span class="p">$</span> sudo ip neigh flush all' . "\n"
         . '<span class="p">$</span> ping -c 2 10.2.3.1') ?>

  <p>Verás el par clásico. El primero va a destino <code>ff:ff:ff:ff:ff:ff</code> —
  broadcast, lo recibe <em>toda</em> la red local — y su Info dice <strong>Who has
  10.2.3.1? Tell 10.2.3.170</strong>. El segundo es la respuesta directa:
  <strong>10.2.3.1 is at ...</strong>.</p>

  <p>ARP no tiene cabecera IP. Es capa 2 pura: solo funciona dentro de tu red local, y por
  eso no hay ARP para <code>1.1.1.1</code> — para salir de la red, todo va al router y él
  se encarga.</p>
</section>

<!-- ======================= EJERCICIO 03 · DNS ======================= -->
<section class="lab" id="e3">
  <div class="lab__head"><span class="lab__num">03</span><h3>DNS: nombres a números</h3></div>
  <p class="lab__goal">Objetivo: emparejar consulta y respuesta, y ver el primer protocolo de aplicación.</p>

  <?= filter_chip('dns') ?>

  <?= term('<span class="p">$</span> dig +short archlinux.org') ?>

  <p>Dos paquetes: <em>Standard query</em> y <em>Standard query response</em>. Despliega la
  consulta y fíjate en el <strong>Transaction ID</strong> — un número aleatorio de 16 bits.
  Ahora mira la respuesta: tiene el mismo ID. Así se emparejan; DNS va normalmente sobre
  UDP, que no tiene conexión, así que la correspondencia hay que llevarla en el propio
  mensaje.</p>

  <p>Dentro de la respuesta, despliega <code>Answers</code>: ahí están las direcciones IP
  reales. Y observa el campo <strong>Time</strong> que Wireshark añade a la respuesta — te
  dice cuánto tardó tu resolver. Eso convierte a Wireshark en una herramienta de
  diagnóstico: un DNS lento se ve aquí de un vistazo.</p>

  <?= note('Detalle de privacidad',
      '<p>El nombre <code>archlinux.org</code> viaja en texto plano. Aunque después la web
      sea HTTPS, la consulta DNS clásica no está cifrada: cualquiera en el camino ve qué
      dominios visitas. Es el motivo de que existan DoH y DoT.</p>') ?>
</section>

<!-- =================== EJERCICIO 04 · HANDSHAKE TCP ================= -->
<section class="lab" id="e4">
  <div class="lab__head"><span class="lab__num">04</span><h3>El handshake de tres vías</h3></div>
  <p class="lab__goal">Objetivo: entender cómo TCP abre una conexión — el concepto central del protocolo.</p>

  <p>Antes de que se envíe un solo byte útil, los dos extremos se sincronizan con tres
  paquetes:</p>

  <figure class="tut-figure">
    <svg viewBox="0 0 480 214" role="img"
         aria-label="Diagrama del handshake TCP de tres vías: el cliente 10.2.3.170 envía SYN con Seq=0, el servidor responde SYN-ACK con Seq=0 y Ack=1, y el cliente cierra con ACK Ack=1, quedando la conexión abierta.">
      <text x="58" y="18" font-family="JetBrains Mono, monospace" font-size="11" fill="var(--dv-text-primary)" text-anchor="middle">10.2.3.170</text>
      <text x="422" y="18" font-family="JetBrains Mono, monospace" font-size="11" fill="var(--dv-text-primary)" text-anchor="middle">servidor:80</text>

      <line x1="58" y1="28" x2="58" y2="204" stroke="var(--dv-border-strong)" stroke-width="1" stroke-dasharray="3 4"/>
      <line x1="422" y1="28" x2="422" y2="204" stroke="var(--dv-border-strong)" stroke-width="1" stroke-dasharray="3 4"/>

      <line x1="58" y1="62" x2="410" y2="62" stroke="var(--tl-l3)" stroke-width="1.7"/>
      <polygon points="422,62 408,57 408,67" fill="var(--tl-l3)"/>
      <text x="240" y="54" font-family="JetBrains Mono, monospace" font-size="12" font-weight="700" fill="var(--tl-l3)" text-anchor="middle">SYN</text>
      <text x="240" y="78" font-family="JetBrains Mono, monospace" font-size="10" fill="var(--dv-text-muted)" text-anchor="middle">Seq=0 · «quiero hablar»</text>

      <line x1="422" y1="120" x2="70" y2="120" stroke="var(--tl-l4)" stroke-width="1.7"/>
      <polygon points="58,120 72,115 72,125" fill="var(--tl-l4)"/>
      <text x="240" y="112" font-family="JetBrains Mono, monospace" font-size="12" font-weight="700" fill="var(--tl-l4)" text-anchor="middle">SYN, ACK</text>
      <text x="240" y="136" font-family="JetBrains Mono, monospace" font-size="10" fill="var(--dv-text-muted)" text-anchor="middle">Seq=0 Ack=1 · «vale, y yo también»</text>

      <line x1="58" y1="178" x2="410" y2="178" stroke="var(--tl-l7)" stroke-width="1.7"/>
      <polygon points="422,178 408,173 408,183" fill="var(--tl-l7)"/>
      <text x="240" y="170" font-family="JetBrains Mono, monospace" font-size="12" font-weight="700" fill="var(--tl-l7)" text-anchor="middle">ACK</text>
      <text x="240" y="194" font-family="JetBrains Mono, monospace" font-size="10" fill="var(--dv-text-muted)" text-anchor="middle">Ack=1 · conexión abierta</text>
    </svg>
    <figcaption>Tres paquetes, cero bytes de datos. Después ya se puede hablar.</figcaption>
  </figure>

  <p>Vamos a verlo. Este filtro aísla exactamente los paquetes de apertura — SYN activo y
  ACK apagado, que solo ocurre en el primer paquete de cada conexión nueva:</p>

  <?= filter_chip('tcp.flags.syn == 1 && tcp.flags.ack == 0') ?>

  <?= term('<span class="p">$</span> curl -s -o /dev/null http://neverssl.com') ?>

  <p>Aparece un SYN. Ahora quita el filtro y en su lugar haz clic derecho sobre ese paquete
  → <strong>Conversation Filter → TCP</strong>. Wireshark escribe solo un filtro con las
  dos IPs y los dos puertos, y te deja la conversación completa: los tres paquetes del
  handshake, la petición HTTP, la respuesta, y el cierre con FIN.</p>

  <p>En el árbol de cada paquete despliega <strong>Flags</strong> dentro de TCP. Los bits
  que importan:</p>

  <div class="tut-table">
    <table>
      <caption class="visually-hidden">Flags de TCP y su significado</caption>
      <thead><tr><th scope="col">Flag</th><th scope="col">Significa</th></tr></thead>
      <tbody>
        <tr><td class="f">SYN</td><td class="d">Abriendo conexión, sincroniza números de secuencia</td></tr>
        <tr><td class="f">ACK</td><td class="d">Confirmo lo que me has mandado hasta el byte N</td></tr>
        <tr><td class="f">PSH</td><td class="d">Entrega estos datos a la aplicación ya, no esperes</td></tr>
        <tr><td class="f">FIN</td><td class="d">He terminado de enviar, cierre ordenado</td></tr>
        <tr><td class="f">RST</td><td class="d">Corte abrupto. Casi siempre señal de problema</td></tr>
      </tbody>
    </table>
  </div>

  <?= note('Truco',
      '<p>Por defecto Wireshark muestra números de secuencia <em>relativos</em> (empiezan
      en 0) para que sean legibles. Los reales son aleatorios de 32 bits. Si alguna vez
      necesitas los de verdad: Edit → Preferences → Protocols → TCP → desmarcar «Relative
      sequence numbers».</p>', 'info') ?>
</section>

<!-- ================== EJERCICIO 05 · FOLLOW STREAM ================== -->
<section class="lab" id="e5">
  <div class="lab__head"><span class="lab__num">05</span><h3>Follow Stream: leer la conversación entera</h3></div>
  <p class="lab__goal">Objetivo: dejar de mirar paquetes sueltos y ver el diálogo.</p>

  <p>Un paquete aislado dice poco. Lo interesante es la conversación reensamblada. Con la
  captura de HTTP del ejercicio anterior todavía abierta, clic derecho en cualquier paquete
  de esa conexión → <strong>Follow → TCP Stream</strong>.</p>

  <p>Se abre una ventana con el diálogo completo en texto: en un color lo que tú enviaste,
  en otro lo que respondió el servidor. Verás literalmente la petición HTTP:</p>

  <?= term("GET / HTTP/1.1\nHost: neverssl.com\nUser-Agent: curl/8.x\nAccept: */*\n\nHTTP/1.1 200 OK\nContent-Type: text/html\n...", 'follow tcp stream') ?>

  <p>Eso es lo que significa que HTTP «no es seguro»: no hace falta ninguna herramienta
  especial, está ahí en claro. Fíjate en que el <code>User-Agent</code> te identifica y el
  <code>Host</code> dice qué sitio pides.</p>

  <p>Al cerrar la ventana, Wireshark deja puesto un filtro <code>tcp.stream eq N</code>. Ese
  número identifica la conexión dentro de la captura, y es una de las formas más rápidas de
  moverse: cambia el número y saltas a otra conversación.</p>

  <p>Prueba también <strong>File → Export Objects → HTTP</strong>: Wireshark lista todos
  los ficheros que viajaron por la captura (páginas, imágenes, scripts) y te los guarda en
  disco reconstruidos.</p>
</section>

<!-- ===================== EJERCICIO 06 · HTTPS/TLS =================== -->
<section class="lab" id="e6">
  <div class="lab__head"><span class="lab__num">06</span><h3>HTTPS: qué se sigue viendo</h3></div>
  <p class="lab__goal">Objetivo: entender qué protege TLS exactamente y qué no.</p>

  <?= filter_chip('tls') ?>

  <?= term('<span class="p">$</span> curl -s -o /dev/null https://archlinux.org') ?>

  <p>Ahora el Follow Stream devuelve ruido binario: el contenido está cifrado. Pero el
  <em>sobre</em> no lo está. Selecciona el primer paquete, el <strong>Client Hello</strong>,
  y despliega hasta las extensiones. Busca <code>server_name</code>:</p>

  <?= filter_chip('tls.handshake.extensions_server_name') ?>

  <p>Ahí está <code>archlinux.org</code>, en texto plano. Es el SNI: el cliente tiene que
  decir a qué sitio se conecta <em>antes</em> de que exista el cifrado, porque una misma IP
  aloja muchos dominios y el servidor necesita saber qué certificado enviar.</p>

  <p>Así que un observador en la red ve: tu IP, la IP del servidor, el dominio (por SNI y
  por DNS), el momento, el volumen y el ritmo del tráfico. Lo que no ve es el contenido:
  qué páginas concretas, qué escribiste, qué te devolvieron.</p>

  <p>Despliega también el <strong>Certificate</strong> en la respuesta del servidor — está
  sin cifrar y contiene el emisor, la validez y el nombre común. Es exactamente lo que tu
  navegador comprueba.</p>
</section>

<!-- ================== EJERCICIO 07 · DESCIFRAR TLS ================== -->
<section class="lab" id="e7">
  <div class="lab__head"><span class="lab__num">07</span><h3>Descifrar tu propio TLS</h3></div>
  <p class="lab__goal">Objetivo: ver HTTPS en claro usando las claves de tu propio navegador.</p>

  <p>No es un ataque: es que el navegador te presta sus claves de sesión porque tú se lo
  pides. Firefox y Chrome escriben las claves efímeras en un fichero si defines
  <code>SSLKEYLOGFILE</code>, y Wireshark sabe leerlo.</p>

  <?= term('<span class="p">$</span> export SSLKEYLOGFILE=~/tls-keys.log' . "\n"
         . '<span class="p">$</span> firefox --new-instance') ?>

  <p>Firefox tiene que arrancar <em>desde esa misma terminal</em> para heredar la variable;
  si ya estaba abierto, ciérralo del todo antes. Luego, en Wireshark:</p>

  <?= term('<span class="c">Edit → Preferences → Protocols → TLS' . "\n"
         . '  → (Pre)-Master-Secret log filename: /home/lucio/tls-keys.log</span>',
         'wireshark · preferencias') ?>

  <p>Empieza la captura, navega a cualquier sitio HTTPS, y filtra por <code>http2</code>.
  Los paquetes que antes eran «Application Data» ilegible ahora aparecen desmontados:
  cabeceras, cookies, JSON, todo. Follow → HTTP/2 Stream lo muestra en texto.</p>

  <?= note('Limpieza',
      '<p>Ese fichero permite descifrar todo lo que capturaste durante esa sesión. Bórralo
      cuando termines (<code>rm ~/tls-keys.log</code>) y no exportes la variable en tu
      <code>.bashrc</code>. Solo funciona con tráfico de <em>tu</em> navegador: no hay forma
      de obtener las claves de nadie más.</p>') ?>
</section>

<!-- ==================== EJERCICIO 08 · STATISTICS =================== -->
<section class="lab" id="e8">
  <div class="lab__head"><span class="lab__num">08</span><h3>El menú Statistics</h3></div>
  <p class="lab__goal">Objetivo: pasar del paquete al panorama. Aquí es donde se diagnostica de verdad.</p>

  <p>Captura treinta segundos de navegación normal, para y recorre el menú
  <strong>Statistics</strong>:</p>

  <h4>Protocol Hierarchy</h4>
  <p>Un desglose porcentual de todo lo capturado por protocolo. Es la primera parada ante
  una captura desconocida: en diez segundos sabes si esto es sobre todo TLS, o hay un
  torrente de UDP, o alguien está haciendo mucho DNS.</p>

  <h4>Conversations</h4>
  <p>Una fila por par de extremos, con bytes y duración. Ordena por la columna
  <strong>Bytes</strong> descendente y tienes al instante quién está consumiendo el ancho de
  banda. Clic derecho en una fila → Apply as Filter para bajar al detalle.</p>

  <h4>Endpoints</h4>
  <p>Lo mismo pero por dirección individual, no por pareja. La pestaña IPv4 tiene una
  casilla de resolución geográfica útil para ver adónde sale tu tráfico.</p>

  <h4>I/O Graph</h4>
  <p>Tráfico en el tiempo. Sirve para ver picos, cortes y patrones periódicos. Puedes añadir
  varias líneas, cada una con su propio display filter — por ejemplo una con
  <code>tcp.analysis.retransmission</code> superpuesta al total, y si las retransmisiones
  suben cuando sube el tráfico, tienes congestión.</p>

  <h4>Expert Information</h4>
  <p>La lista de todo lo que Wireshark considera anómalo, clasificado por severidad.
  Retransmisiones, ACKs duplicados, ventanas a cero, conexiones reiniciadas. Ante «la red va
  lenta», este diálogo es el atajo.</p>

  <p>Y el filtro de diagnóstico que más se usa:</p>

  <?= filter_chip('tcp.analysis.flags') ?>

  <p>Muestra solo los paquetes que Wireshark ha marcado como problemáticos. En una red sana,
  apenas aparece nada.</p>
</section>

<!-- ====================== EJERCICIO 09 · TSHARK ===================== -->
<section class="lab" id="e9">
  <div class="lab__head"><span class="lab__num">09</span><h3>tshark: lo mismo sin ventana</h3></div>
  <p class="lab__goal">Objetivo: capturar en servidores, en scripts y en sesiones SSH.</p>

  <p><code>tshark</code> es el mismo motor sin GUI, con los mismos display filters. Captura
  diez paquetes DNS y muéstralos:</p>

  <?= term('<span class="p">$</span> tshark -i wlan0 -c 10 -f "port 53"') ?>

  <p>Fíjate en <code>-f</code>: es el <em>capture</em> filter (sintaxis BPF). El display
  filter va con <code>-Y</code>:</p>

  <?= term('<span class="p">$</span> tshark -i wlan0 -Y "dns.flags.response == 0"') ?>

  <p>Lo más potente es extraer campos concretos en columnas, listo para <code>sort</code> o
  <code>awk</code>:</p>

  <?= term('<span class="p">$</span> tshark -i wlan0 -Y dns -T fields \\' . "\n"
         . '      -e frame.time_relative -e ip.src -e dns.qry.name') ?>

  <p>El flujo de trabajo habitual es capturar sin interfaz y analizar con la GUI:</p>

  <?= term('<span class="c"># capturar 60 s a fichero</span>' . "\n"
         . '<span class="p">$</span> tshark -i wlan0 -a duration:60 -w ~/captura.pcapng' . "\n\n"
         . '<span class="c"># abrirlo en la GUI</span>' . "\n"
         . '<span class="p">$</span> wireshark ~/captura.pcapng') ?>

  <p>El formato <code>.pcapng</code> es estándar: lo lee cualquier herramienta de análisis,
  y es lo que te pasarán si alguien te pide ayuda con un problema de red. Guardar la captura
  (<kbd>Ctrl</kbd>+<kbd>S</kbd>) es parte del trabajo, no un extra.</p>
</section>

<!-- ============================= CHULETA ============================ -->
<section id="chuleta">
  <h2>Chuleta de display filters</h2>
  <p class="tut-sub">Los que se usan a diario.</p>

  <div class="tut-table">
    <table>
      <caption class="visually-hidden">Display filters de uso diario y qué muestra cada uno</caption>
      <thead><tr><th scope="col">Filtro</th><th scope="col">Qué muestra</th></tr></thead>
      <tbody>
        <tr><td class="f">ip.addr == 10.2.3.1</td><td class="d">Todo lo que va o viene de esa IP</td></tr>
        <tr><td class="f">ip.src == 10.2.3.170</td><td class="d">Solo lo que sale de tu equipo</td></tr>
        <tr><td class="f">tcp.port == 443</td><td class="d">Tráfico HTTPS por puerto</td></tr>
        <tr><td class="f">dns || icmp || arp</td><td class="d">Varios protocolos a la vez</td></tr>
        <tr><td class="f">!(arp || dns)</td><td class="d">Todo menos el ruido de fondo</td></tr>
        <tr><td class="f">http.request</td><td class="d">Solo peticiones HTTP, sin respuestas</td></tr>
        <tr><td class="f">http.response.code &gt;= 400</td><td class="d">Errores HTTP</td></tr>
        <tr><td class="f">tcp.flags.reset == 1</td><td class="d">Conexiones cortadas de golpe</td></tr>
        <tr><td class="f">tcp.analysis.retransmission</td><td class="d">Paquetes reenviados: pérdida en la red</td></tr>
        <tr><td class="f">tcp.stream eq 3</td><td class="d">Una conversación TCP concreta</td></tr>
        <tr><td class="f">frame contains "password"</td><td class="d">Busca una cadena en el contenido crudo</td></tr>
        <tr><td class="f">frame.len &gt; 1400</td><td class="d">Paquetes grandes, cerca del MTU</td></tr>
      </tbody>
    </table>
  </div>

  <p>Operadores: <code>==</code> <code>!=</code> <code>&gt;</code> <code>&lt;</code> para
  comparar; <code>&amp;&amp;</code> o <code>and</code>, <code>||</code> o <code>or</code>,
  <code>!</code> o <code>not</code> para combinar; <code>contains</code> para subcadenas y
  <code>matches</code> para expresiones regulares.</p>

  <p>Y el atajo que hace innecesario memorizar nada: <strong>clic derecho sobre cualquier
  campo del árbol → Apply as Filter → Selected</strong>. Wireshark escribe el filtro
  correcto y así es como se aprenden los nombres de los campos — trabajando, no estudiando
  una lista.</p>

  <aside class="tut-legal">
    <h3>Sobre dónde capturar</h3>
    <p>Todo lo de esta guía captura tu propio tráfico en tu propia máquina. Analizar tráfico
    en redes que no son tuyas o sin autorización del propietario es ilegal en la mayoría de
    jurisdicciones, incluida España. En una red wifi propia estás en tu derecho; en la de
    una cafetería, una empresa o un vecino, no.</p>
  </aside>
</section>
