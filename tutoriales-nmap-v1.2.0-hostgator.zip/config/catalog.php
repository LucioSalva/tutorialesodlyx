<?php
/**
 * Tutoriales Lucio · CODLYX — catálogo de respaldo y whitelist de vistas
 * ---------------------------------------------------------------------
 * Este fichero cumple DOS funciones, ambas de seguridad o continuidad:
 *
 *  1. `views`   — WHITELIST. El campo `view_key` llega desde MySQL, es
 *                 decir, desde fuera del código. Jamás se concatena a una
 *                 ruta de fichero. Solo se acepta si es una clave EXACTA
 *                 de este array; el valor es el nombre de vista real.
 *                 Sin esto, un `view_key` como '../../config/config'
 *                 sería path traversal. Con esto, es simplemente inválido.
 *
 *  2. `tutorials` — CATÁLOGO DE RESPALDO. Si MySQL está deshabilitado,
 *                 mal configurado o caído, la biblioteca se sirve desde
 *                 aquí y el sitio sigue siendo navegable. Mantén esta
 *                 lista alineada con database/seed.sql.
 *
 * Al añadir un tutorial nuevo hay que tocar los DOS arrays. El README
 * lo explica paso a paso en «Agregar un nuevo tutorial».
 */

declare(strict_types=1);

return [

    /**
     * Whitelist  view_key => nombre de vista en app/Views/tutorials/<nombre>.php
     * La clave debe coincidir con tutorials.view_key en la base de datos.
     */
    'views' => [
        'wireshark' => 'wireshark',
        'nmap'      => 'nmap',
    ],

    /**
     * Catálogo de respaldo. Mismos campos que devuelve la consulta SQL,
     * para que las vistas no distingan de dónde vienen los datos.
     */
    'tutorials' => [
        [
            'slug'        => 'wireshark',
            'name'        => 'Wireshark',
            'tagline'     => 'Análisis de paquetes y ciberseguridad defensiva',
            'description' => 'Curso completo en cinco partes: fundamentos de captura, los protocolos capa por capa (Ethernet, ARP, IPv4, IPv6, ICMP, TCP, UDP, DNS, DHCP, HTTP y TLS), las herramientas de Wireshark a fondo, análisis defensivo de tráfico y doce laboratorios prácticos con desafíos.',
            'icon'        => 'wireshark',
            'view_key'    => 'wireshark',
            'status'      => 'available',
            'category'    => 'Redes',
            'sort_order'  => 10,
        ],
        [
            'slug'        => 'nmap',
            'name'        => 'Nmap',
            'tagline'     => 'Descubrimiento de red y ciberseguridad defensiva',
            'description' => 'Curso completo en diez niveles: fundamentos y modelo mental, descubrimiento de hosts y CIDR, escaneo de puertos (TCP connect, SYN y UDP), detección de servicios y sistema operativo, el motor de scripts NSE con categorías seguras, resultados y reporting, ciberseguridad defensiva (superficie, hardening, validación de firewall y detección de escaneos), análisis avanzado y quince laboratorios prácticos sobre localhost y laboratorio propio.',
            'icon'        => 'nmap',
            'view_key'    => 'nmap',
            'status'      => 'available',
            'category'    => 'Redes',
            'sort_order'  => 15,
        ],
        [
            'slug'        => 'ssh',
            'name'        => 'SSH',
            'tagline'     => 'Acceso remoto seguro',
            'description' => '',
            'icon'        => 'ssh',
            'view_key'    => null,
            'status'      => 'coming_soon',
            'category'    => 'Sistemas',
            'sort_order'  => 20,
        ],
    ],

    /**
     * Índice de secciones de respaldo, por slug de tutorial.
     * Espejo de la tabla tutorial_sections.
     */
    'sections' => [
        'nmap' => [
            ['anchor' => 'que-es',          'label' => 'Qué es Nmap',                  'badge' => '01', 'group' => 'Fundamentos'],
            ['anchor' => 'alcance',         'label' => 'Autorización y alcance',       'badge' => '02', 'group' => 'Fundamentos'],
            ['anchor' => 'modelo',          'label' => 'El modelo mental',              'badge' => '03', 'group' => 'Fundamentos'],
            ['anchor' => 'instalar',        'label' => 'Instalar y validar',            'badge' => '04', 'group' => 'Fundamentos'],
            ['anchor' => 'privilegios',     'label' => 'Privilegios: sudo',             'badge' => '05', 'group' => 'Fundamentos'],
            ['anchor' => 'tcp-udp',         'label' => 'TCP y UDP',                     'badge' => '06', 'group' => 'Fundamentos'],
            ['anchor' => 'primer',          'label' => 'Primer escaneo',                'badge' => '07', 'group' => 'Fundamentos'],
            ['anchor' => 'salida',          'label' => 'Anatomía de la salida',        'badge' => '08', 'group' => 'Fundamentos'],
            ['anchor' => 'estados',         'label' => 'Estados de puerto',             'badge' => '09', 'group' => 'Fundamentos'],
            ['anchor' => 'cidr',            'label' => 'CIDR',                          'badge' => '10', 'group' => 'Descubrimiento'],
            ['anchor' => 'mi-red',          'label' => 'Identificar tu red',            'badge' => '11', 'group' => 'Descubrimiento'],
            ['anchor' => 'objetivos',       'label' => 'Especificar objetivos',         'badge' => '12', 'group' => 'Descubrimiento'],
            ['anchor' => 'list-scan',       'label' => 'List scan (-sL)',               'badge' => '13', 'group' => 'Descubrimiento'],
            ['anchor' => 'descubrimiento',  'label' => 'Host discovery (-sn)',          'badge' => '14', 'group' => 'Descubrimiento'],
            ['anchor' => 'pn',              'label' => 'Omitir descubrimiento (-Pn)',   'badge' => '15', 'group' => 'Descubrimiento'],
            ['anchor' => 'dns',             'label' => 'DNS y nombres',                 'badge' => '16', 'group' => 'Descubrimiento'],
            ['anchor' => 'puertos',         'label' => 'Seleccionar puertos (-p)',      'badge' => '17', 'group' => 'Puertos'],
            ['anchor' => 'comunes',         'label' => 'Puertos comunes',               'badge' => '18', 'group' => 'Puertos'],
            ['anchor' => 'connect',         'label' => 'TCP connect (-sT)',             'badge' => '19', 'group' => 'Puertos'],
            ['anchor' => 'syn',             'label' => 'SYN scan (-sS)',                'badge' => '20', 'group' => 'Puertos'],
            ['anchor' => 'st-vs-ss',        'label' => '-sT frente a -sS',              'badge' => '21', 'group' => 'Puertos'],
            ['anchor' => 'udp',             'label' => 'Escaneo UDP (-sU)',             'badge' => '22', 'group' => 'Puertos'],
            ['anchor' => 'combinado',       'label' => 'TCP y UDP juntos',              'badge' => '23', 'group' => 'Puertos'],
            ['anchor' => 'razones',         'label' => 'Verbosidad y razones',          'badge' => '24', 'group' => 'Puertos'],
            ['anchor' => 'versiones',       'label' => 'Servicios y versiones (-sV)',   'badge' => '25', 'group' => 'Servicios'],
            ['anchor' => 'importa-version', 'label' => '¿Por qué importa la versión?', 'badge' => '26', 'group' => 'Servicios'],
            ['anchor' => 'os',              'label' => 'Detección de SO (-O)',         'badge' => '27', 'group' => 'Sistema operativo'],
            ['anchor' => 'traceroute',      'label' => 'Camino al objetivo',            'badge' => '28', 'group' => 'Sistema operativo'],
            ['anchor' => 'agresivo',        'label' => 'La opción -A',                 'badge' => '29', 'group' => 'Sistema operativo'],
            ['anchor' => 'timing',          'label' => 'Timing (-T0 a -T5)',            'badge' => '30', 'group' => 'Sistema operativo'],
            ['anchor' => 'fuera-alcance',   'label' => 'Fuera de alcance',              'badge' => '31', 'group' => 'Sistema operativo'],
            ['anchor' => 'nse',             'label' => 'Qué es NSE',                   'badge' => '32', 'group' => 'NSE'],
            ['anchor' => 'nse-categorias',  'label' => 'Categorías NSE',               'badge' => '33', 'group' => 'NSE'],
            ['anchor' => 'script-help',     'label' => '--script-help',                 'badge' => '34', 'group' => 'NSE'],
            ['anchor' => 'nse-seguros',     'label' => 'Scripts seguros',               'badge' => '35', 'group' => 'NSE'],
            ['anchor' => 'nse-http',        'label' => 'NSE sobre HTTP',                'badge' => '36', 'group' => 'NSE'],
            ['anchor' => 'nse-tls',         'label' => 'NSE sobre TLS',                 'badge' => '37', 'group' => 'NSE'],
            ['anchor' => 'nse-info',        'label' => 'NSE: SSH y DNS',                'badge' => '38', 'group' => 'NSE'],
            ['anchor' => 'guardar',         'label' => 'Guardar resultados',            'badge' => '39', 'group' => 'Resultados'],
            ['anchor' => 'formatos',        'label' => '¿Qué formato usar?',          'badge' => '40', 'group' => 'Resultados'],
            ['anchor' => 'comparar',        'label' => 'Comparar escaneos',             'badge' => '41', 'group' => 'Resultados'],
            ['anchor' => 'inventario',      'label' => 'Inventario de red',             'badge' => '42', 'group' => 'Resultados'],
            ['anchor' => 'superficie',      'label' => 'Superficie de ataque',          'badge' => '43', 'group' => 'Ciberseguridad'],
            ['anchor' => 'inesperados',     'label' => 'Servicios inesperados',         'badge' => '44', 'group' => 'Ciberseguridad'],
            ['anchor' => 'hardening',       'label' => 'Inventario y hardening',        'badge' => '45', 'group' => 'Ciberseguridad'],
            ['anchor' => 'firewall',        'label' => 'Validar un firewall',           'badge' => '46', 'group' => 'Ciberseguridad'],
            ['anchor' => 'deteccion',       'label' => 'Detectar escaneos',             'badge' => '47', 'group' => 'Ciberseguridad'],
            ['anchor' => 'wireshark',       'label' => 'Nmap + Wireshark',              'badge' => '48', 'group' => 'Ciberseguridad'],
            ['anchor' => 'limitaciones',    'label' => 'Falsos positivos',              'badge' => '49', 'group' => 'Análisis avanzado'],
            ['anchor' => 'errores',         'label' => 'Errores comunes',               'badge' => '50', 'group' => 'Análisis avanzado'],
            ['anchor' => 'metodologia',     'label' => 'Árbol de decisión',           'badge' => '51', 'group' => 'Análisis avanzado'],
            ['anchor' => 'auditoria',       'label' => 'Flujo de auditoría',           'badge' => '52', 'group' => 'Análisis avanzado'],
            ['anchor' => 'informe',         'label' => 'Mini informe',                  'badge' => '53', 'group' => 'Análisis avanzado'],
            ['anchor' => 'hecho-hipotesis', 'label' => 'Hechos vs hipótesis',          'badge' => '54', 'group' => 'Análisis avanzado'],
            ['anchor' => 'labs',            'label' => '15 laboratorios',               'badge' => '55', 'group' => 'Práctica'],
            ['anchor' => 'desafios',        'label' => 'Desafíos',                     'badge' => '56', 'group' => 'Práctica'],
            ['anchor' => 'chuleta',         'label' => 'Chuleta de Nmap',               'badge' => '57', 'group' => 'Práctica'],
        ],

        'wireshark' => [
            ['anchor' => 'que-es',           'label' => 'Qué es Wireshark',        'badge' => '01', 'group' => 'Fundamentos'],
            ['anchor' => 'instalar',         'label' => 'Instalar y permisos',     'badge' => '02', 'group' => 'Fundamentos'],
            ['anchor' => 'interfaz',         'label' => 'La interfaz por dentro',  'badge' => '03', 'group' => 'Fundamentos'],
            ['anchor' => 'ventana',          'label' => 'Los tres paneles',        'badge' => '04', 'group' => 'Fundamentos'],
            ['anchor' => 'mental',           'label' => 'Encapsulación y capas',   'badge' => '05', 'group' => 'Fundamentos'],
            ['anchor' => 'filtros',          'label' => 'Captura vs. visualización', 'badge' => '06', 'group' => 'Fundamentos'],
            ['anchor' => 'display-filters',  'label' => 'Lenguaje de filtros',     'badge' => '07', 'group' => 'Fundamentos'],
            ['anchor' => 'ethernet',         'label' => 'Ethernet',                'badge' => '08', 'group' => 'Protocolos'],
            ['anchor' => 'arp',              'label' => 'ARP',                     'badge' => '09', 'group' => 'Protocolos'],
            ['anchor' => 'ipv4',             'label' => 'IPv4',                    'badge' => '10', 'group' => 'Protocolos'],
            ['anchor' => 'ipv6',             'label' => 'IPv6',                    'badge' => '11', 'group' => 'Protocolos'],
            ['anchor' => 'icmp',             'label' => 'ICMP',                    'badge' => '12', 'group' => 'Protocolos'],
            ['anchor' => 'tcp',              'label' => 'TCP',                     'badge' => '13', 'group' => 'Protocolos'],
            ['anchor' => 'udp',              'label' => 'UDP',                     'badge' => '14', 'group' => 'Protocolos'],
            ['anchor' => 'dns',              'label' => 'DNS',                     'badge' => '15', 'group' => 'Protocolos'],
            ['anchor' => 'dhcp',             'label' => 'DHCP',                    'badge' => '16', 'group' => 'Protocolos'],
            ['anchor' => 'http',             'label' => 'HTTP',                    'badge' => '17', 'group' => 'Protocolos'],
            ['anchor' => 'tls',              'label' => 'HTTPS y TLS',             'badge' => '18', 'group' => 'Protocolos'],
            ['anchor' => 'follow',           'label' => 'Follow Stream',           'badge' => '19', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'statistics',       'label' => 'Statistics',              'badge' => '20', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'expert',           'label' => 'Expert Information',      'badge' => '21', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'coloring',         'label' => 'Coloring rules',          'badge' => '22', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'columnas',         'label' => 'Columnas propias',        'badge' => '23', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'perfiles',         'label' => 'Perfiles',                'badge' => '24', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'tls-descifrado',   'label' => 'Descifrar TLS propio',    'badge' => '25', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'tshark',           'label' => 'tshark',                  'badge' => '26', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'pcap',             'label' => 'PCAP y su custodia',      'badge' => '27', 'group' => 'Wireshark a fondo'],
            ['anchor' => 'ciber',            'label' => 'Análisis defensivo',      'badge' => '28', 'group' => 'Ciberseguridad'],
            ['anchor' => 'baseline',         'label' => 'Línea base',              'badge' => '29', 'group' => 'Ciberseguridad'],
            ['anchor' => 'scan',             'label' => 'Escaneo de puertos',      'badge' => '30', 'group' => 'Ciberseguridad'],
            ['anchor' => 'beaconing',        'label' => 'Beaconing',               'badge' => '31', 'group' => 'Ciberseguridad'],
            ['anchor' => 'dns-raro',         'label' => 'DNS sospechoso',          'badge' => '32', 'group' => 'Ciberseguridad'],
            ['anchor' => 'arp-raro',         'label' => 'ARP anómalo',             'badge' => '33', 'group' => 'Ciberseguridad'],
            ['anchor' => 'exfil',            'label' => 'Exfiltración',            'badge' => '34', 'group' => 'Ciberseguridad'],
            ['anchor' => 'http-raro',        'label' => 'HTTP sospechoso',         'badge' => '35', 'group' => 'Ciberseguridad'],
            ['anchor' => 'claro',            'label' => 'Credenciales en claro',   'badge' => '36', 'group' => 'Ciberseguridad'],
            ['anchor' => 'resets',           'label' => 'Resets y pérdidas',       'badge' => '37', 'group' => 'Ciberseguridad'],
            ['anchor' => 'flujo',            'label' => 'Flujo de análisis',       'badge' => '38', 'group' => 'Ciberseguridad'],
            ['anchor' => 'informe',          'label' => 'Informe de incidente',    'badge' => '39', 'group' => 'Ciberseguridad'],
            ['anchor' => 'labs',             'label' => '12 laboratorios',         'badge' => '40', 'group' => 'Práctica'],
            ['anchor' => 'desafios',         'label' => 'Desafíos',                'badge' => '41', 'group' => 'Práctica'],
            ['anchor' => 'errores',          'label' => 'Errores comunes',         'badge' => '42', 'group' => 'Práctica'],
            ['anchor' => 'chuleta',          'label' => 'Chuleta de filtros',      'badge' => '43', 'group' => 'Práctica'],
        ],
    ],
];
