<?php
/**
 * Tutoriales Lucio · CODLYX — catálogo de respaldo y whitelist de vistas
 * ---------------------------------------------------------------------
 * Este fichero cumple DOS funciones, ambas de seguridad o continuidad:
 *
 *  1. `views`   — WHITELIST. El campo `view_key` llega desde MySQL, es
 *                 decir, desde fuera del código. Jamás se concatena a una
 *                 ruta de fichero. Solo se acepta si es una clave EXACTA
 *                 de este array; el valor es el nombre de vista real.
 *                 Sin esto, un `view_key` como '../../config/config'
 *                 sería path traversal. Con esto, es simplemente inválido.
 *
 *  2. `tutorials` — CATÁLOGO DE RESPALDO. Si MySQL está deshabilitado,
 *                 mal configurado o caído, la biblioteca se sirve desde
 *                 aquí y el sitio sigue siendo navegable. Mantén esta
 *                 lista alineada con database/seed.sql.
 *
 * Al añadir un tutorial nuevo hay que tocar los DOS arrays. El README
 * lo explica paso a paso en «Agregar un nuevo tutorial».
 */

declare(strict_types=1);

return [

    /**
     * Whitelist  view_key => nombre de vista en app/Views/tutorials/<nombre>.php
     * La clave debe coincidir con tutorials.view_key en la base de datos.
     */
    'views' => [
        'wireshark' => 'wireshark',
    ],

    /**
     * Catálogo de respaldo. Mismos campos que devuelve la consulta SQL,
     * para que las vistas no distingan de dónde vienen los datos.
     */
    'tutorials' => [
        [
            'slug'        => 'wireshark',
            'name'        => 'Wireshark',
            'tagline'     => 'Análisis de paquetes y protocolos',
            'description' => 'Nueve laboratorios encadenados sobre una máquina real: ICMP, ARP, DNS, el handshake TCP, Follow Stream, TLS y su descifrado con SSLKEYLOGFILE, el menú Statistics y tshark en terminal.',
            'icon'        => 'wireshark',
            'view_key'    => 'wireshark',
            'status'      => 'available',
            'category'    => 'Redes',
            'sort_order'  => 10,
        ],
        [
            'slug'        => 'ssh',
            'name'        => 'SSH',
            'tagline'     => 'Acceso remoto seguro',
            'description' => '',
            'icon'        => 'ssh',
            'view_key'    => null,
            'status'      => 'coming_soon',
            'category'    => 'Sistemas',
            'sort_order'  => 20,
        ],
    ],

    /**
     * Índice de secciones de respaldo, por slug de tutorial.
     * Espejo de la tabla tutorial_sections.
     */
    'sections' => [
        'wireshark' => [
            ['anchor' => 'instalar', 'label' => 'Instalar',           'badge' => ''],
            ['anchor' => 'mental',   'label' => 'Modelo mental',      'badge' => ''],
            ['anchor' => 'ventana',  'label' => 'La ventana',         'badge' => ''],
            ['anchor' => 'filtros',  'label' => 'Filtros',            'badge' => ''],
            ['anchor' => 'e1',       'label' => 'Ping / ICMP',        'badge' => '01'],
            ['anchor' => 'e2',       'label' => 'ARP',                'badge' => '02'],
            ['anchor' => 'e3',       'label' => 'DNS',                'badge' => '03'],
            ['anchor' => 'e4',       'label' => 'Handshake TCP',      'badge' => '04'],
            ['anchor' => 'e5',       'label' => 'Follow Stream',      'badge' => '05'],
            ['anchor' => 'e6',       'label' => 'HTTPS / TLS',        'badge' => '06'],
            ['anchor' => 'e7',       'label' => 'Descifrar TLS',      'badge' => '07'],
            ['anchor' => 'e8',       'label' => 'Estadísticas',       'badge' => '08'],
            ['anchor' => 'e9',       'label' => 'tshark',             'badge' => '09'],
            ['anchor' => 'chuleta',  'label' => 'Chuleta de filtros', 'badge' => ''],
        ],
    ],
];
