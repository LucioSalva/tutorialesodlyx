<?php
/**
 * Bloques didácticos reutilizables.
 *
 * Los usan las vistas de tutorial para no repetir el mismo armazón HTML
 * decenas de veces. Cuando se añada un tutorial nuevo, hereda estos
 * componentes sin escribir marcado propio.
 *
 * Nota sobre el escapado: `$html` en term() y note() es contenido de autor
 * escrito dentro de una vista PHP del propio repositorio, no entrada de
 * usuario. Los valores que SÍ podrían venir de fuera (expresiones de filtro,
 * etiquetas) se escapan con e().
 */

if (!function_exists('block_uid')) {
    /** Identificador incremental y estable dentro de una misma respuesta. */
    function block_uid(string $prefix): string
    {
        static $n = 0;
        return $prefix . '-' . (++$n);
    }
}

if (!function_exists('term')) {
    /**
     * Bloque de terminal con botón de copiar.
     *
     * @param string $html  contenido ya marcado (usa <span class="p">$</span>
     *                      para el prompt y <span class="c">…</span> para
     *                      comentarios; el prompt se excluye al copiar)
     * @param string $label etiqueta de la barra superior
     */
    function term(string $html, string $label = 'bash'): string
    {
        $id = block_uid('term');

        return '<div class="term">'
             . '<div class="term__bar">'
             . '<span class="term__label">' . e($label) . '</span>'
             . '<button type="button" class="term__copy" data-copy="' . e($id) . '" '
             . 'data-label-idle="Copiar" data-label-aria="Copiar comando" '
             . 'aria-label="Copiar comando">Copiar</button>'
             . '</div>'
             . '<pre id="' . e($id) . '"><code>' . $html . '</code></pre>'
             . '</div>';
    }
}

if (!function_exists('filter_chip')) {
    /**
     * Chip de display filter de Wireshark, con copia directa.
     * La expresión se escapa: puede contener &&, <, > y comillas.
     */
    function filter_chip(string $expression, string $tag = 'Display'): string
    {
        $id = block_uid('filter');

        return '<div class="filter">'
             . '<span class="filter__tag">' . e($tag) . '</span>'
             . '<code class="filter__val" id="' . e($id) . '">' . e($expression) . '</code>'
             . '<button type="button" class="filter__copy" data-copy="' . e($id) . '" '
             . 'data-label-aria="Copiar filtro" '
             . 'aria-label="Copiar filtro ' . e($expression) . '">'
             . icon('copy', 15)
             . '</button>'
             . '</div>';
    }
}

if (!function_exists('note')) {
    /**
     * Callout. $variant: 'warn' (por defecto) o 'info'.
     */
    function note(string $label, string $html, string $variant = 'warn'): string
    {
        $class = $variant === 'info' ? 'note note--info' : 'note';

        return '<aside class="' . $class . '">'
             . '<span class="note__label">' . e($label) . '</span>'
             . $html
             . '</aside>';
    }
}

if (!function_exists('chapter')) {
    /**
     * Separador de capítulo. Marca el paso de un bloque temático al siguiente
     * (Fundamentos → Protocolos → Wireshark a fondo → Ciberseguridad → Práctica)
     * para que un tutorial largo se lea como un curso y no como un muro.
     *
     * @param string $numero  «01», «02»…
     * @param string $nivel   clave de dificultad; ver difficulty()
     */
    function chapter(string $numero, string $titulo, string $bajada, string $nivel): string
    {
        return '<div class="chapter">'
             . '<div class="chapter__top">'
             . '<span class="chapter__num">Parte ' . e($numero) . '</span>'
             . difficulty($nivel)
             . '</div>'
             . '<h2 class="chapter__title">' . e($titulo) . '</h2>'
             . '<p class="chapter__sub">' . e($bajada) . '</p>'
             . '</div>';
    }
}

if (!function_exists('difficulty')) {
    /**
     * Insignia de nivel. El texto lleva la información, no solo el color:
     * quien no distinga los tonos sigue leyendo «Ciberseguridad».
     */
    function difficulty(string $nivel): string
    {
        $niveles = [
            'fundamentos' => 'Fundamentos',
            'protocolos'  => 'Protocolos',
            'intermedio'  => 'Intermedio',
            'ciber'       => 'Ciberseguridad',
            'practica'    => 'Práctica',
        ];

        $etiqueta = $niveles[$nivel] ?? ucfirst($nivel);

        return '<span class="level level--' . e($nivel) . '">' . e($etiqueta) . '</span>';
    }
}

if (!function_exists('reveal')) {
    /**
     * Bloque plegable con <details> nativo: sin JavaScript, accesible por
     * teclado y buscable por el navegador (Ctrl+F lo despliega en Chrome).
     * Se usa para soluciones de desafíos y para detalle opcional que no debe
     * interrumpir la lectura principal.
     */
    function reveal(string $resumen, string $html, string $variante = ''): string
    {
        $clase = 'reveal' . ($variante !== '' ? ' reveal--' . $variante : '');

        return '<details class="' . e($clase) . '">'
             . '<summary>' . e($resumen) . '</summary>'
             . '<div class="reveal__body">' . $html . '</div>'
             . '</details>';
    }
}

if (!function_exists('lab_head')) {
    /**
     * Cabecera de laboratorio: número, título, nivel y objetivo en una sola
     * pieza, para que los doce labs se lean con la misma forma.
     */
    function lab_head(string $numero, string $titulo, string $nivel, string $objetivo): string
    {
        return '<div class="lab__head">'
             . '<span class="lab__num">' . e($numero) . '</span>'
             . '<h3>' . e($titulo) . '</h3>'
             . difficulty($nivel)
             . '</div>'
             . '<p class="lab__goal">' . e($objetivo) . '</p>';
    }
}

if (!function_exists('steps')) {
    /**
     * Lista de pasos numerada de un laboratorio.
     * @param list<string> $pasos  HTML de autor, uno por paso
     */
    function steps(array $pasos): string
    {
        $html = '';
        foreach ($pasos as $paso) {
            $html .= '<li>' . $paso . '</li>';
        }
        return '<ol class="steps">' . $html . '</ol>';
    }
}
