<?php
/**
 * Bloques didácticos reutilizables.
 *
 * Los usan las vistas de tutorial para no repetir el mismo armazón HTML
 * decenas de veces. Cuando se añada un tutorial nuevo, hereda estos
 * componentes sin escribir marcado propio.
 *
 * Nota sobre el escapado: `$html` en term() y note() es contenido de autor
 * escrito dentro de una vista PHP del propio repositorio, no entrada de
 * usuario. Los valores que SÍ podrían venir de fuera (expresiones de filtro,
 * etiquetas) se escapan con e().
 */

if (!function_exists('block_uid')) {
    /** Identificador incremental y estable dentro de una misma respuesta. */
    function block_uid(string $prefix): string
    {
        static $n = 0;
        return $prefix . '-' . (++$n);
    }
}

if (!function_exists('term')) {
    /**
     * Bloque de terminal con botón de copiar.
     *
     * @param string $html  contenido ya marcado (usa <span class="p">$</span>
     *                      para el prompt y <span class="c">…</span> para
     *                      comentarios; el prompt se excluye al copiar)
     * @param string $label etiqueta de la barra superior
     */
    function term(string $html, string $label = 'bash'): string
    {
        $id = block_uid('term');

        return '<div class="term">'
             . '<div class="term__bar">'
             . '<span class="term__label">' . e($label) . '</span>'
             . '<button type="button" class="term__copy" data-copy="' . e($id) . '" '
             . 'data-label-idle="Copiar" data-label-aria="Copiar comando" '
             . 'aria-label="Copiar comando">Copiar</button>'
             . '</div>'
             . '<pre id="' . e($id) . '"><code>' . $html . '</code></pre>'
             . '</div>';
    }
}

if (!function_exists('filter_chip')) {
    /**
     * Chip de display filter de Wireshark, con copia directa.
     * La expresión se escapa: puede contener &&, <, > y comillas.
     */
    function filter_chip(string $expression, string $tag = 'Display'): string
    {
        $id = block_uid('filter');

        return '<div class="filter">'
             . '<span class="filter__tag">' . e($tag) . '</span>'
             . '<code class="filter__val" id="' . e($id) . '">' . e($expression) . '</code>'
             . '<button type="button" class="filter__copy" data-copy="' . e($id) . '" '
             . 'data-label-aria="Copiar filtro" '
             . 'aria-label="Copiar filtro ' . e($expression) . '">'
             . icon('copy', 15)
             . '</button>'
             . '</div>';
    }
}

if (!function_exists('note')) {
    /**
     * Callout. $variant: 'warn' (por defecto) o 'info'.
     */
    function note(string $label, string $html, string $variant = 'warn'): string
    {
        $class = $variant === 'info' ? 'note note--info' : 'note';

        return '<aside class="' . $class . '">'
             . '<span class="note__label">' . e($label) . '</span>'
             . $html
             . '</aside>';
    }
}
